  jQuery(function() {
    jQuery( "#everything_tab" ).tabs({ heightStyle:"auto",show:{effect:"fadeIn",duration:500} });
  });